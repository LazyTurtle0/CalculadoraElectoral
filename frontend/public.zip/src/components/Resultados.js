
import React from 'react';

function Resultados() {
  return (
    <div>
      <h2>Resultados</h2>
      {/* Lógica para mostrar los resultados */}
    </div>
  );
}

export default Resultados;
