import React, { useState } from 'react';
import axios from 'axios';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import '../styles/styles.css'; // Adjust the path if necessary

function CargarCSV() {
  const [file, setFile] = useState(null);
  const [cedula, setCedula] = useState('');
  const [partidos, setPartidos] = useState([]);
  const [resultados, setResultados] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleCedulaChange = (e) => {
    setCedula(e.target.value);
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:3001/api/partidos/procesar-csv', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setPartidos(response.data.map(partido => ({ ...partido, votosValidos: partido.votosValidos || 0 })));
    } catch (error) {
      console.error('Error al procesar el archivo CSV:', error.response ? error.response.data : error.message);
    }
  };

  const handleVotosChange = (index, votos) => {
    const newPartidos = [...partidos];
    const votosValidos = isNaN(parseInt(votos, 10)) ? 0 : parseInt(votos, 10);
    newPartidos[index].votosValidos = votosValidos;
    setPartidos(newPartidos);
  };

  const handleProcesarDatos = async () => {
    try {
      const response = await axios.post('http://localhost:3001/api/partidos/procesar-datos', {
        partidos,
      });
      setResultados(response.data);
    } catch (error) {
      console.error('Error al procesar los datos:', error.response ? error.response.data : error.message);
    }
  };

  const handleDescargarPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Reporte de Resultados', 14, 20);
    doc.text(`Persona encargada: ${cedula}`, 14, 30);

    doc.setFontSize(14);
    doc.text('Resultados de Cálculo', 14, 40);
    doc.setFontSize(12);
    doc.text(`Total de Votos Válidos: ${resultados.totalVotosValidos}`, 14, 50);
    doc.text(`Cociente: ${resultados.cociente}`, 14, 60);
    doc.text(`Subcociente: ${resultados.subcociente}`, 14, 70);

    doc.setFontSize(14);
    doc.text('Asignación de Asientos (Tabla 1)', 14, 80);
    doc.autoTable({
      startY: 90,
      head: [['Partido', 'Votos Válidos', 'Votos Restantes', 'Asientos Asignados', 'Votos Residuales', 'Gano con Residual']],
      body: resultados.partidosFinal.map(partido => [
        partido.nombre,
        partido.votosValidos,
        partido.votosRestantes,
        partido.asientosAsignados,
        partido.votosRestantes,
        partido.ganoConResidual ? 'Sí' : 'No',
      ]),
      didParseCell: function (data) {
        const partido = resultados.partidosFinal[data.row.index];
        if (partido.ganoConResidual) {
          data.cell.styles.fillColor = [204, 229, 255]; // Blue for residual
        }
      }
    });

    doc.text('Ganadores (Tabla 2)', 14, doc.autoTable.previous.finalY + 20);
    doc.autoTable({
      startY: doc.autoTable.previous.finalY + 30,
      head: [['Partido', 'Propietario', 'Suplente']],
      body: resultados.ganadores.map(ganador => [
        ganador.partido,
        ganador.propietario.nombre || 'No indica',
        ganador.suplente.nombre || 'No indica',
      ]),
      didParseCell: function (data) {
        const ganador = resultados.ganadores[data.row.index];
        if (ganador.destacar === 'red') {
          data.cell.styles.fillColor = [248, 215, 218]; // Red for doble postulación
        } else if (ganador.destacar === 'yellow') {
          data.cell.styles.fillColor = [255, 243, 205]; // Yellow for movement
        } else if (ganador.destacar === 'blue') {
          data.cell.styles.fillColor = [204, 229, 255]; // Blue for empate
        } else if (ganador.destacar === 'purple') {
          data.cell.styles.fillColor = [226, 208, 255]; // Purple for multiple conditions
        }
      }
    });

    doc.save('reporte_resultados.pdf');
  };

  const getRowStyle = (destacar) => {
    switch (destacar) {
      case "red":
        return { backgroundColor: '#f8d7da' };
      case "yellow":
        return { backgroundColor: '#fff3cd' };
      case "blue":
        return { backgroundColor: '#cce5ff' };
      case "purple":
        return { backgroundColor: '#e2d0ff' }; // Color lila para múltiples condiciones
      default:
        return {};
    }
  };

  return (
    <div className="App">
      <h1>Calculadora Electoral</h1>

      <div className="form-group">
        <label>Cédula:</label>
        <input type="text" value={cedula} onChange={handleCedulaChange} />
      </div>

      <div className="form-group">
        <input type="file" onChange={handleFileChange} disabled={!cedula} />
        <button onClick={handleSubmit} disabled={!cedula}>Cargar CSV</button>
      </div>

      {partidos.length > 0 && (
        <div>
          <h3>Ingresar Votos Válidos</h3>
          <div className="partidos-container">
            <form>
              {partidos.map((partido, index) => (
                <div key={`${partido.nombre}-${index}`}>
                  <label>
                    {partido.nombre} ({partido.distrito}):
                    <input
                      type="number"
                      value={partido.votosValidos}
                      onChange={(e) => handleVotosChange(index, e.target.value)}
                      step="1"
                      min="0"
                    />
                  </label>
                </div>
              ))}
            </form>
            <button onClick={handleProcesarDatos}>Procesar Datos</button>
          </div>
        </div>
      )}

      {resultados && (
        <div className="section">
          <h3>Resultados de Cálculo</h3>
          <p>Total de Votos Válidos: {resultados.totalVotosValidos}</p>
          <p>Cociente: {resultados.cociente}</p>
          <p>Subcociente: {resultados.subcociente}</p>

          <h3>Asignación de Asientos (Tabla 1)</h3>
          <table>
            <thead>
              <tr>
                <th>Partido</th>
                <th>Votos Válidos</th>
                <th>Votos Restantes</th>
                <th>Asientos Asignados</th>
                <th>Votos Residuales</th>
                <th>Gano con Residual</th>
              </tr>
            </thead>
            <tbody>
              {resultados.partidosFinal.map((partido, index) => (
                <tr key={index} style={partido.ganoConResidual ? { backgroundColor: '#cce5ff' } : {}}>
                  <td>{partido.nombre}</td>
                  <td>{partido.votosValidos}</td>
                  <td>{partido.votosRestantes}</td>
                  <td>{partido.asientosAsignados}</td>
                  <td>{partido.votosRestantes}</td>
                  <td>{partido.ganoConResidual ? 'Sí' : 'No'}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3>Ganadores (Tabla 2)</h3>
          <table>
            <thead>
              <tr>
                <th>Partido</th>
                <th>Propietario</th>
                <th>Suplente</th>
              </tr>
            </thead>
            <tbody>
              {resultados.ganadores.map((ganador, index) => (
                <tr key={index} style={getRowStyle(ganador.destacar)}>
                  <td>{ganador.partido}</td>
                  <td>{ganador.propietario.nombre || 'No indica'}</td>
                  <td>{ganador.suplente.nombre || 'No indica'}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <button onClick={handleDescargarPDF}>Descargar PDF</button>
        </div>
      )}
    </div>
  );
}

export default CargarCSV;

